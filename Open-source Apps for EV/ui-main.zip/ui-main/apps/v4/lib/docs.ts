export const PAGES_NEW = [
  "/docs/components/button-group",
  "/docs/components/empty",
  "/docs/components/field",
  "/docs/components/input-group",
  "/docs/components/item",
  "/docs/components/kbd",
  "/docs/components/spinner",
  "/docs/components/native-select",
]

export const PAGES_UPDATED = ["/docs/components/button"]
