export default function CustomersPage() {
  return (
    <div className="p-6">
      <div className="bg-input p-4">Input</div>
      <div className="bg-input/30 p-4">Input 50</div>
    </div>
  )
}
