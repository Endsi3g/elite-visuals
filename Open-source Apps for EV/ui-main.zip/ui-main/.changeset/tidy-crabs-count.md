---
"shadcn": patch
---

Fix utils import transform when workspace alias does not start with @
